/* Italian locals for flatpickr */
var Flatpickr = Flatpickr || { l10ns: {} };
Flatpickr.l10ns.italian = {};

Flatpickr.l10ns.italian.weekdays = {
	shorthand: ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'],
	longhand: ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato']
};

Flatpickr.l10ns.italian.months = {
	shorthand: ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'],
	longhand: ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre']
};

Flatpickr.l10ns.italian.firstDayOfWeek = 1;

Flatpickr.l10ns.italian.ordinal = '°';

Flatpickr.l10ns.italian.weekAbbreviation = 'Se';

Flatpickr.l10ns.italian.scrollTitle = 'Scrolla per aumentare';

Flatpickr.l10ns.italian.toggleTitle = 'Clicca per cambiare';

if (typeof module !== "undefined") {
	module.exports = Flatpickr.l10ns;
}