<?php
$lang['event_invoice_overdue'] = 'De betaling van de factuur {invoice_number} is <span class="label label-important">te laat!</span>';
$lang['event_project_overdue'] = 'Project {project_number} heeft de <span class="label label-important">deadline bereikt!</span>';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Nieuwe factuur</span> nodig voor abonnement {subscription_number}!';

