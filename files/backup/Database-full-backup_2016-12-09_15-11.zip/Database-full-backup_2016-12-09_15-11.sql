#
# TABLE STRUCTURE FOR: article_has_attachments
#

DROP TABLE IF EXISTS article_has_attachments;

CREATE TABLE `article_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(140) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(180) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `userpic` varchar(150) NOT NULL DEFAULT 'no-pic.png',
  `city` varchar(45) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `access` varchar(150) DEFAULT '0',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('27', '25', 'John', 'Doe', 'emailtesterone@gmail.com', '8989898989', '9898989898', 'Iscon Elegance', '380015', 'c690a0f8cc6bc0d96283f9a8d01a9d4e.png', 'Ahmedabad', 'a520895c9828ca296cf15f46402445c8f598a9f8c40997c14012a66055d72f547c3bc821ae5490fbc976ad25ed425703470458ba594fdb7e14da9b6b9c6508ee', '0', '14,12,13,107', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('28', '26', 'ABC', 'ABC', 'emailtesterone@gmail.com', '121212', '11212121', '', '', '1aa98a0e6dc94897ebbecde5629581f5.png', '', '336cf1fad5b2b76027433ea3932da87efc6b9cecef0bcf87192655c7ec5a43f603956b530f09e744a2e2bbcec0d2fd176de236ff52144b5f18d3bff73c3eb196', '1', '14,12,13,107,15,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('29', '27', 'Ann', 'Gerlitz', 'emailtestertwo@gmail.com', '7854545421', '1212121212', 'Dallas', '75251', '53f5648177c6c53a40537ad5f95947d4.png', 'Dallas', '905c80c170515c443a52d041dd79c0d1e407de61612ef39b4ffdecc32ffe1cfdf43a24dbf4d9790930e6b98f359026d613e18231b18cd7229d9b765ac7bdca85', '0', '14,12,13,107,15,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('30', '27', 'Angel', 'Gerlitz', 'emailtesterone@gmail.com', '87554221', '9725555555', 'Dallas', '75252', '3181e02c4bbc7bb34d52e7401f766e15.jpg', 'Dallas', 'c075cd88cb339b54174791f9e1fedeb5dad80bfa8a933c810baa0ea087815cabdfa23ece0424ff5afd1c1f21f9177ae52a40ce66b830d60db28e65005ddabd6c', '0', '14,12,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('31', '28', 'Antago', 'Mario', 'emailtesterthree@gmail.com', '54787879', '32655487', 'Sydney', '2000', '49b22e8ddec0d134066acdd514db5b59.png', 'Sydney', '7cb3867632e3e24467d9994ab1835fe599446cd4eb5a4eeeab741dc684e181e9319444f07f553a1a1351debeaa8104b2e58b6483dff3327975fa7966a38d6526', '0', '14,12,13,107,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('32', '29', 'Mark', 'Zuckerburg', 'emailtesterthree@gmail.com', '758758757', '578787878', 'USA', '78181', '16407b73f3fe1add317906184e901f40.jpg', 'LA', '9e57091a78193501b1ebc2bceaee0f0b7a111fa8075fc0ba2be09041666d828a22d7dd8ddc46a6dd8eb60db2183dc94215b009ba762afeef222d4eddda1acc6f', '0', '14,12,13,107,15,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('33', '30', 'Rajat', 'Sharma', 'emailtestorone.@gmail.com', '9854521548', '9875468982', 'Mumbai', '400066', '647bfb53db069592ce153cbc2f39aa77.jpg', 'Mumbai', 'f0a4b9c1fc8d646d7489c7441a7dcd7165a0f39c74694ef226be690a56c04c605a8e4ce7854aaa57d8c4ac46289a1b1158b2cf9bdfdfde8bceecd5186e7ce999', '0', '14,12,13,107,15,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('34', '28', 'Laura', 'Evans', 'emailtesterone@gmail.com', '8798665320', '9758528510', 'Atlanta', '30301', '05fc0040de0911f64014d7b332e6401c.jpg', 'ATlanta', '13797188fe5663b1b3a6b69a3b469d27098576164b81d0feb25f538f4dcc3ba8c20b2d142c0c95c8b010d81a4721d79905a0597432f8a8059a6238a7de1092f2', '0', '14,12,107,15,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('35', '31', 'Dr. Shubhash', 'Chandra', 'emailtestertwo@gmail.com', '9754548581', '9723134215', 'Delhi', '110001', 'no-pic.png', 'Delhi', '51604ad36661e1082d424ebf80cb6881ab3859dfb56459e906dc2bbd7e3a407ac3371a5e0b2868202ae96012bd062c03d4d47a0feb11fe396942f90b1eb3c98e', '0', '14,12,13,107,15,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('36', '31', 'Punit', 'Goenka', 'emailtesterfour@gmail.com', '9875451246', '9726885551', 'Mumbai', '400066', 'no-pic.png', 'Mumbai', '76b86747d52b1fafb6e67c017236f29cb9e134c9f02d0d64faca5292b52a87dd5f241de0565ff8c49fe99ae1a1ae79dae3d842c0c70f4ad87dcaf10152fabcb0', '0', '14,12,13,107,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('37', '31', 'Neharika', 'Goenka', 'emailtesterfour@gmail.com', '9782451110', '9775454141', '', '400066', 'bba4af750dbbb526761e9bf814bcedd8.png', 'Mumbai', 'a8adc365ecbdcc4e46bd14e58145b5e68eb16bcaf3fd263c7f9ba41545b98cf51c620976653a0a626939404b3b2b59608289cd433dda970d1bc58ec11ecedde9', '0', '14,12,13,107,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('39', '34', 'Honey', 'Wells', 'emailtesterfive@gmail.com', '', '', 'Dallas', '75252', 'no-pic.png', 'Dallas', '1b6fc4b616040e03cbcbe4bc6e88c8b6a5d339fb1ca99295c64050faa85801389a86b8f16e3643f32fc37e73452b8595bda2623f76b8c9f71805a84fe1a6c5b3', '0', '14,12,13,107,15,17', '0', '1481286350');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('40', '35', 'Steve', 'Jobs', 'emailtestersix@gmail.com', '', '', 'LA', '43589', 'no-pic.png', 'LA', '8075fa591725ab708ce10c770f591d97eacb254c1cec6932d242b084f397638a6a810f3123fb5c62494ef6c250ecd705eef1d73931baff2c6a110ddb2f558bbe', '0', '14,15,17', '0', '1481286527');


#
# TABLE STRUCTURE FOR: companies
#

DROP TABLE IF EXISTS companies;

CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `name` varchar(140) DEFAULT NULL,
  `client_id` varchar(140) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `website` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `vat` varchar(250) DEFAULT NULL,
  `note` longtext,
  `province` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('25', '41001', 'KGN', '27', '9999999999', '8888888888', 'iscon elegance', '380015', 'Ahmedabad', '0', 'kgntechnologies.com', 'India', '', NULL, 'Gujarat');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('26', '41002', 'ABC', '28', '1111', '8989898989898', 'ABC', '380015', 'Ahmedabad', '1', 'ABC.com', 'India', '', NULL, 'Gujarat');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('27', '41003', 'Microsoft', '29', '7878787878', '7744774412', 'USA', '75252', 'Dallas', '0', 'microsoft.com', 'USA', '', NULL, 'Texas');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('28', '41004', 'Google', '31', '7875454542', '9721212543', 'sydney', '2000', 'Sydney', '0', 'google.com', 'Australia', '', NULL, 'NSW');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('29', '41005', 'Facebook', '32', '878787545', '9722222215', 'USA', '78788', 'LA', '0', 'facebook', 'USA', '', NULL, 'California');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('30', '41006', 'ICICI', '33', '989898989', '7921212124', 'Ahmedabad', '380015', 'Ahmedabad', '0', 'ICICI.com', 'India', '', NULL, 'Gujarat');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('31', '41007', 'Zee Telefilms', '35', '9585825487', '9725856564', 'Delhi', '98514', 'Delhi', '0', 'zee.com', 'India', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('32', '41008', 'Hello Testing', NULL, '54654654', '54654876978', 'lkdjfgiu', '687676', 'djfsdh', '0', 'test.com', 'kdjfgsdh', '', NULL, 'qkljfgkjdsfglj');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('33', '41009', 'SPERA', '38', '97513456', '9784561235', 'Dallas', '75252', 'Dallas', '0', 'http://spera.io', 'USA', '', NULL, 'TEXAS');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('34', '41010', 'SPERA1', '39', '', '', 'Dallas', '75252', 'Dallas', '0', '', 'India', '', NULL, 'TEXAS');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('35', '41011', 'ALCATEL', '40', '', '', 'LA', '43589', 'LA', '0', '', 'USA', '', NULL, 'CALIFORNIA');


#
# TABLE STRUCTURE FOR: company_has_admins
#

DROP TABLE IF EXISTS company_has_admins;

CREATE TABLE `company_has_admins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `access` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('2', '25', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('3', '25', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('4', '26', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('5', '26', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('6', '27', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('7', '27', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('8', '27', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('9', '28', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('10', '28', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('11', '29', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('12', '29', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('13', '30', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('14', '30', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('15', '28', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('16', '31', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('17', '31', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('18', '31', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('19', '31', '9', '');
INSERT INTO company_has_admins (`id`, `company_id`, `user_id`, `access`) VALUES ('20', '32', '11', '');


#
# TABLE STRUCTURE FOR: core
#

DROP TABLE IF EXISTS core;

CREATE TABLE `core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` char(10) NOT NULL DEFAULT '0',
  `domain` varchar(65) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `tax` varchar(5) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `autobackup` int(11) DEFAULT NULL,
  `cronjob` int(11) DEFAULT NULL,
  `last_cronjob` int(11) DEFAULT NULL,
  `last_autobackup` int(11) DEFAULT NULL,
  `invoice_terms` mediumtext,
  `company_reference` int(6) DEFAULT NULL,
  `project_reference` int(6) DEFAULT NULL,
  `invoice_reference` int(6) DEFAULT NULL,
  `subscription_reference` int(6) DEFAULT NULL,
  `ticket_reference` int(10) DEFAULT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `date_time_format` varchar(20) DEFAULT NULL,
  `invoice_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_link_mail_subject` varchar(150) DEFAULT NULL,
  `credentials_mail_subject` varchar(150) DEFAULT NULL,
  `notification_mail_subject` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `invoice_address` varchar(200) DEFAULT NULL,
  `invoice_city` varchar(200) DEFAULT NULL,
  `invoice_contact` varchar(200) DEFAULT NULL,
  `invoice_tel` varchar(50) DEFAULT NULL,
  `subscription_mail_subject` varchar(250) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `template` varchar(200) DEFAULT 'blueline',
  `paypal` varchar(5) DEFAULT '1',
  `paypal_currency` varchar(200) DEFAULT 'EUR',
  `paypal_account` varchar(200) DEFAULT '',
  `invoice_logo` varchar(150) DEFAULT 'assets/blueline/img/invoice_logo.png',
  `pc` varchar(150) DEFAULT NULL,
  `vat` varchar(150) DEFAULT NULL,
  `ticket_email` varchar(250) DEFAULT NULL,
  `ticket_default_owner` int(10) DEFAULT '1',
  `ticket_default_queue` int(10) DEFAULT '1',
  `ticket_default_type` int(10) DEFAULT '1',
  `ticket_default_status` varchar(200) DEFAULT 'new',
  `ticket_config_host` varchar(250) DEFAULT NULL,
  `ticket_config_login` varchar(250) DEFAULT NULL,
  `ticket_config_pass` varchar(250) DEFAULT NULL,
  `ticket_config_port` varchar(250) DEFAULT NULL,
  `ticket_config_ssl` varchar(250) DEFAULT NULL,
  `ticket_config_email` varchar(250) DEFAULT NULL,
  `ticket_config_flags` varchar(250) DEFAULT '/notls',
  `ticket_config_search` varchar(250) DEFAULT 'UNSEEN',
  `ticket_config_timestamp` int(11) DEFAULT '0',
  `ticket_config_mailbox` varchar(250) DEFAULT NULL,
  `ticket_config_delete` int(11) DEFAULT '0',
  `ticket_config_active` int(11) DEFAULT '0',
  `ticket_config_imap` int(11) DEFAULT '1',
  `stripe` int(11) DEFAULT '0',
  `stripe_key` varchar(250) DEFAULT NULL,
  `stripe_p_key` varchar(255) DEFAULT '',
  `stripe_currency` varchar(255) DEFAULT 'USD',
  `bank_transfer` int(11) DEFAULT '0',
  `bank_transfer_text` longtext,
  `estimate_terms` longtext,
  `estimate_prefix` varchar(250) DEFAULT 'EST',
  `estimate_pdf_template` varchar(250) DEFAULT 'templates/estimate/blueline',
  `invoice_pdf_template` varchar(250) DEFAULT 'templates/invoice/blueline',
  `second_tax` varchar(5) DEFAULT '',
  `estimate_mail_subject` varchar(255) DEFAULT 'New Estimate #{estimate_id}',
  `money_format` int(20) unsigned NOT NULL DEFAULT '1',
  `money_currency_position` int(20) unsigned NOT NULL DEFAULT '1',
  `pdf_font` varchar(255) DEFAULT 'NotoSans',
  `pdf_path` int(10) unsigned NOT NULL DEFAULT '1',
  `registration` int(10) unsigned NOT NULL DEFAULT '0',
  `authorize_api_login_id` varchar(255) DEFAULT NULL,
  `authorize_api_transaction_key` varchar(255) DEFAULT NULL,
  `authorize_net` int(20) DEFAULT NULL,
  `authorize_currency` varchar(30) DEFAULT NULL,
  `invoice_prefix` varchar(255) NOT NULL DEFAULT '',
  `company_prefix` varchar(255) NOT NULL DEFAULT '',
  `quotation_prefix` varchar(255) NOT NULL DEFAULT '',
  `project_prefix` varchar(255) NOT NULL DEFAULT '',
  `subscription_prefix` varchar(255) NOT NULL DEFAULT '',
  `calendar_google_api_key` varchar(255) DEFAULT NULL,
  `calendar_google_event_address` varchar(255) DEFAULT NULL,
  `default_client_modules` varchar(255) DEFAULT NULL,
  `estimate_reference` int(10) NOT NULL,
  `login_background` varchar(255) DEFAULT 'field.jpg',
  `custom_colors` int(1) DEFAULT '1',
  `top_bar_background` varchar(60) DEFAULT '#FFFFFF',
  `top_bar_color` varchar(60) DEFAULT '#333333',
  `body_background` varchar(60) DEFAULT '#D8DCE3',
  `menu_background` varchar(60) DEFAULT '#2c3e4d',
  `menu_color` varchar(60) DEFAULT '#FFFFFF',
  `primary_color` varchar(60) DEFAULT '#28a9f1',
  `twocheckout_seller_id` varchar(250) DEFAULT '',
  `twocheckout_publishable_key` varchar(250) DEFAULT '',
  `twocheckout_private_key` varchar(250) DEFAULT '',
  `twocheckout` int(11) DEFAULT '0',
  `twocheckout_currency` varchar(250) DEFAULT '',
  `login_logo` varchar(255) DEFAULT '',
  `login_style` varchar(255) DEFAULT 'left',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO core (`id`, `version`, `domain`, `email`, `company`, `tax`, `currency`, `autobackup`, `cronjob`, `last_cronjob`, `last_autobackup`, `invoice_terms`, `company_reference`, `project_reference`, `invoice_reference`, `subscription_reference`, `ticket_reference`, `date_format`, `date_time_format`, `invoice_mail_subject`, `pw_reset_mail_subject`, `pw_reset_link_mail_subject`, `credentials_mail_subject`, `notification_mail_subject`, `language`, `invoice_address`, `invoice_city`, `invoice_contact`, `invoice_tel`, `subscription_mail_subject`, `logo`, `template`, `paypal`, `paypal_currency`, `paypal_account`, `invoice_logo`, `pc`, `vat`, `ticket_email`, `ticket_default_owner`, `ticket_default_queue`, `ticket_default_type`, `ticket_default_status`, `ticket_config_host`, `ticket_config_login`, `ticket_config_pass`, `ticket_config_port`, `ticket_config_ssl`, `ticket_config_email`, `ticket_config_flags`, `ticket_config_search`, `ticket_config_timestamp`, `ticket_config_mailbox`, `ticket_config_delete`, `ticket_config_active`, `ticket_config_imap`, `stripe`, `stripe_key`, `stripe_p_key`, `stripe_currency`, `bank_transfer`, `bank_transfer_text`, `estimate_terms`, `estimate_prefix`, `estimate_pdf_template`, `invoice_pdf_template`, `second_tax`, `estimate_mail_subject`, `money_format`, `money_currency_position`, `pdf_font`, `pdf_path`, `registration`, `authorize_api_login_id`, `authorize_api_transaction_key`, `authorize_net`, `authorize_currency`, `invoice_prefix`, `company_prefix`, `quotation_prefix`, `project_prefix`, `subscription_prefix`, `calendar_google_api_key`, `calendar_google_event_address`, `default_client_modules`, `estimate_reference`, `login_background`, `custom_colors`, `top_bar_background`, `top_bar_color`, `body_background`, `menu_background`, `menu_color`, `primary_color`, `twocheckout_seller_id`, `twocheckout_publishable_key`, `twocheckout_private_key`, `twocheckout`, `twocheckout_currency`, `login_logo`, `login_style`) VALUES ('1', '3.0.3', 'http://localhost/cockpit-3-pm/FC_Application/', 'emailtesterone@gmail.com', '86 Robot', '0', '$', '1', '1', '0', '0', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '41012', '51009', '31003', '61002', '10004', 'Y/m/d', 'g:i A', 'New Invoice', 'Password Reset', 'Password Reset', 'Login Details', 'Notification', 'english', '506, ISCON Elegance, Near Prahladnagar, SG Road,', 'Ahmedabad', 'KGN', '380015', 'New Subscription', 'assets/blueline/images/FC2_logo_light.png', 'blueline', '0', 'USD', '', 'assets/blueline/images/FC2_logo_dark.png', '27168c93-44e2-48da-b8ab-4cb83a6074c3', NULL, NULL, '1', '1', '1', 'new', NULL, NULL, NULL, NULL, NULL, NULL, '/notls', 'UNSEEN', '0', NULL, '0', '0', '1', '0', NULL, '', 'USD', '0', NULL, NULL, 'EST', 'templates/estimate/blueline', 'templates/invoice/blueline', '', 'New Estimate #{estimate_id}', '1', '1', 'NotoSans', '1', '1', NULL, NULL, NULL, NULL, '', '', '', '', '', NULL, NULL, '14,15,17', '20001', 'table2.jpg', '1', '#ffffff', '#333333', '#d8dce3', 'rgba(123,139,153,0.19)', '#ffffff', '#5fbeaa', '', '', '', '0', '', 'files/media/FC2_logo_dark.png', 'left');


#
# TABLE STRUCTURE FOR: custom_quotation_requests
#

DROP TABLE IF EXISTS custom_quotation_requests;

CREATE TABLE `custom_quotation_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form` longtext,
  `custom_quotation_id` int(11) unsigned NOT NULL,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_quotations
#

DROP TABLE IF EXISTS custom_quotations;

CREATE TABLE `custom_quotations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '',
  `formcontent` longtext,
  `inactive` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: events
#

DROP TABLE IF EXISTS events;

CREATE TABLE `events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `description` text,
  `allday` varchar(30) DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `classname` varchar(255) DEFAULT '',
  `start` varchar(255) DEFAULT '',
  `end` varchar(255) DEFAULT '',
  `user_id` bigint(20) DEFAULT '0',
  `access` varchar(255) DEFAULT '',
  `reminder` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) DEFAULT '',
  `type` varchar(250) DEFAULT '',
  `category` varchar(250) DEFAULT '',
  `date` varchar(250) DEFAULT '',
  `currency` varchar(250) DEFAULT '',
  `value` float DEFAULT '0',
  `vat` varchar(250) DEFAULT '',
  `reference` varchar(250) DEFAULT '',
  `project_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rebill` int(20) unsigned NOT NULL DEFAULT '0',
  `invoice_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attachment` varchar(250) DEFAULT '',
  `attachment_description` varchar(250) DEFAULT '',
  `recurring` varchar(250) DEFAULT '',
  `recurring_until` varchar(250) DEFAULT '',
  `user_id` int(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('2', 'Give 10% discount', 'refund', 'KGN ', '2016-12-05', '$', '3000', '', '', '11', '1', '0', '', '', '', '', '9');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('3', 'Electricity Bill', 'payment', 'Electricity', '2016-12-07', '$', '200', '', '', '11', '0', '0', '', '', '', '', '9');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('4', 'Travel expense is related to pickup, drop and stay facility for clients', 'payment', 'Travel', '2016-12-07', '$', '200', '', '', '11', '0', '0', '', '', '', '', '9');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('5', 'Advertising ', 'payment', 'Advertising and Promotion', '2016-12-06', '$3000', '50', '', '', '0', '0', '0', '', '', '', '', '9');


#
# TABLE STRUCTURE FOR: invoice_has_items
#

DROP TABLE IF EXISTS invoice_has_items;

CREATE TABLE `invoice_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` text,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('2', '31', '17', '1', '', '1', 'Create Customised Add Plugin', '1');


#
# TABLE STRUCTURE FOR: invoice_has_payments
#

DROP TABLE IF EXISTS invoice_has_payments;

CREATE TABLE `invoice_has_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) DEFAULT '0',
  `reference` varchar(250) DEFAULT '',
  `amount` float DEFAULT '0',
  `date` varchar(20) DEFAULT '',
  `type` varchar(250) DEFAULT '',
  `notes` text,
  `user_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO invoice_has_payments (`id`, `invoice_id`, `reference`, `amount`, `date`, `type`, `notes`, `user_id`) VALUES ('2', '31', '31002001', '6000', '2016-12-08', 'cash', 'Received', '9');


#
# TABLE STRUCTURE FOR: invoices
#

DROP TABLE IF EXISTS invoices;

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `due_date` varchar(20) DEFAULT NULL,
  `sent_date` varchar(20) DEFAULT NULL,
  `paid_date` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscription_id` varchar(50) DEFAULT '0',
  `project_id` int(11) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  `estimate` int(11) DEFAULT '0',
  `estimate_status` varchar(255) DEFAULT '0',
  `estimate_accepted_date` varchar(255) DEFAULT '0',
  `estimate_sent` varchar(255) DEFAULT '0',
  `sum` float DEFAULT '0',
  `second_tax` varchar(5) DEFAULT '',
  `estimate_reference` varchar(255) DEFAULT '',
  `paid` float DEFAULT NULL,
  `outstanding` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`, `paid`, `outstanding`) VALUES ('29', '31001', '25', 'Open', '$1000', '2016-12-01', '2016-12-20', NULL, NULL, 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '', '0', '11', '0', '0', '0', '0', '0', '0', '', '', NULL, '0');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`, `paid`, `outstanding`) VALUES ('31', '31002', '31', 'PartiallyPaid', '$6000', '2016-12-07', '2016-12-16', NULL, '2016-12-08', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '', '0', '16', '0', '0', '0', '0', '0', '1', '', '', '6000', '-5999');


#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS items;

CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `value` float DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('17', 'Create Customised Add Plugin', '1', '1', '0', '');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('18', 'Create Photo\'s &amp; Video\'s Module', '1', 'Create Photo\'s &amp; Video\'s Module', '0', '');


#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS messages;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `media_id` int(11) DEFAULT '0',
  `from` varchar(120) DEFAULT NULL,
  `text` text,
  `datetime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `link` varchar(250) DEFAULT '0',
  `type` varchar(250) DEFAULT '0',
  `icon` varchar(150) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('1', 'Dashboard', 'dashboard', 'main', 'fa-dashboard', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('2', 'Messages', 'messages', 'main', 'fa-inbox', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('3', 'Projects', 'projects', 'main', 'fa-lightbulb-o', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('4', 'Clients', 'clients', 'main', 'fa-users', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('5', 'Invoices', 'invoices', 'main', 'fa-file-text-o', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('6', 'Items', 'items', 'main', 'fa-archive', '7');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('7', 'Quotations', 'quotations', 'main', 'fa-file-text-o', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('8', 'Subscriptions', 'subscriptions', 'main', 'fa-calendar', '6');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('9', 'Settings', 'settings', 'main', 'fa-cog', '20');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('10', 'QuickAccess', 'quickaccess', 'widget', NULL, '50');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('11', 'User Online', 'useronline', 'widget', NULL, '51');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('12', 'Projects', 'cprojects', 'client', 'fa-lightbulb-o', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('13', 'Invoices', 'cinvoices', 'client', 'fa-file-text-o', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('14', 'Messages', 'cmessages', 'client', 'fa-inbox', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('15', 'Subscriptions', 'csubscriptions', 'client', 'fa-calendar', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('16', 'Tickets', 'tickets', 'main', 'fa-tag', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('17', 'Tickets', 'ctickets', 'client', 'fa-tag', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('18', 'Estimates', 'estimates', 'main', 'fa-files-o', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('19', 'Expenses', 'expenses', 'main', 'fa-money', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('20', 'Calendar', 'calendar', 'main', 'fa-calendar', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('33', 'Reports', 'reports', 'main', 'fa-area-chart', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('107', 'Estimates', 'cestimates', 'client', 'fa-files-o', '3');


#
# TABLE STRUCTURE FOR: privatemessages
#

DROP TABLE IF EXISTS privatemessages;

CREATE TABLE `privatemessages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(150) NOT NULL,
  `sender` varchar(250) NOT NULL,
  `recipient` varchar(250) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `time` varchar(100) NOT NULL,
  `conversation` varchar(255) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0',
  `attachment` varchar(255) DEFAULT '',
  `attachment_link` varchar(255) DEFAULT '',
  `receiver_delete` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`) VALUES ('125', 'New', 'u9', 'c27', 'Hi', '<p>Hi<br></p>', '2016-12-07 09:03', 'bd2ab3f6691528525fca4d7980a0a4ee1c8ac87b', '0', '', '', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`) VALUES ('126', 'Replied', 'u9', 'u10', 'Hi ', '<p>This is a testing message for the first time<br></p>', '2016-12-07 12:45', '27cf02ca58feec40357603c964fc0761b8d13cd4', '0', '', '', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`) VALUES ('127', 'New', 'u9', 'c28', '!st Message', '<p>!st Message<br></p>', '2016-12-07 13:11', '3521eded1d6c34b566aaa388af6fa9b8b112de15', '0', '', '', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`) VALUES ('128', 'Replied', 'u10', 'u9', 'Hi ', '<p>Hey John,</p><p>how are you?<br></p>', '2016-12-07 13:14', '27cf02ca58feec40357603c964fc0761b8d13cd4', '0', '', '', '0');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`, `receiver_delete`) VALUES ('129', 'Read', 'u10', 'u9', 'Hi ', '<p>Hey John,</p><p>Thanks for texting..<br>Please tell me what\'s the reason behind message?<br></p>', '2016-12-07 13:15', '27cf02ca58feec40357603c964fc0761b8d13cd4', '0', '', '', '0');


#
# TABLE STRUCTURE FOR: project_has_activities
#

DROP TABLE IF EXISTS project_has_activities;

CREATE TABLE `project_has_activities` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `user_id` bigint(20) DEFAULT '0',
  `client_id` bigint(20) DEFAULT '0',
  `datetime` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` longtext,
  `type` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('1', '16', '9', '0', '1481198970', 'HEYYYYY', '<p>We Have started....<br></p>', 'comment');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('2', '16', '9', '0', '1481199968', 'HI ', '<p>HEY<br></p>', 'comment');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('3', '16', '9', '0', '1481200294', '!', '<p>!<br></p>', 'comment');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('4', '16', '9', '0', '1481200400', '1', '<p>1<br></p>', 'comment');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('5', '17', '9', '0', '1481277535', '', '<p>dgfcfgd<br></p>', 'comment');


#
# TABLE STRUCTURE FOR: project_has_files
#

DROP TABLE IF EXISTS project_has_files;

CREATE TABLE `project_has_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `client_id` int(10) DEFAULT '0',
  `type` varchar(80) DEFAULT '0',
  `name` varchar(120) DEFAULT '0',
  `filename` varchar(150) DEFAULT '0',
  `description` text,
  `savename` varchar(200) DEFAULT '0',
  `phase` varchar(100) DEFAULT '0',
  `date` varchar(50) DEFAULT '0',
  `download_counter` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('1', '16', '9', '0', 'image/jpeg', 'ajay-shivaay-mithoon-759.jpg', 'ajay-shivaay-mithoon-759.jpg', NULL, '97b3d644639b98a53e3d2e90700c7f89.jpg', '', '2016-12-08 11:22', '0');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('2', '16', '9', '0', 'image/jpeg', 'doctor-strange.jpg', 'doctor-strange.jpg', NULL, '098eb231bd5d19747cd960673558265f.jpg', '', '2016-12-08 11:22', '0');


#
# TABLE STRUCTURE FOR: project_has_invoices
#

DROP TABLE IF EXISTS project_has_invoices;

CREATE TABLE `project_has_invoices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `invoice_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_milestones
#

DROP TABLE IF EXISTS project_has_milestones;

CREATE TABLE `project_has_milestones` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `due_date` varchar(255) DEFAULT '',
  `orderindex` int(11) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`) VALUES ('1', '16', 'Neharika', '<p>Please achieve this milestone as this is alot urgent task.. thanks<br></p>', '2016-12-16', NULL, '2016-12-12');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`) VALUES ('2', '16', 'Mr. Shubhash Chandra', '', '2016-12-30', NULL, '2016-12-12');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`) VALUES ('3', '16', 'Kerry', '', '2016-12-23', NULL, '2016-12-01');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`) VALUES ('4', '13', 'Google', '', '2016-12-09', NULL, '2016-12-08');
INSERT INTO project_has_milestones (`id`, `project_id`, `name`, `description`, `due_date`, `orderindex`, `start_date`) VALUES ('5', '13', 'Gmail', '', '2016-12-23', NULL, '2016-12-08');


#
# TABLE STRUCTURE FOR: project_has_tasks
#

DROP TABLE IF EXISTS project_has_tasks;

CREATE TABLE `project_has_tasks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `name` varchar(250) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT '0',
  `public` int(10) DEFAULT '0',
  `datetime` int(11) DEFAULT NULL,
  `due_date` varchar(250) DEFAULT NULL,
  `description` text,
  `value` float NOT NULL DEFAULT '0',
  `priority` smallint(6) DEFAULT '0',
  `time` int(11) DEFAULT '0',
  `client_id` int(30) DEFAULT NULL,
  `created_by_client` int(30) DEFAULT '0',
  `tracking` int(11) DEFAULT NULL,
  `time_spent` int(11) DEFAULT NULL,
  `milestone_id` int(11) DEFAULT '0',
  `invoice_id` int(60) DEFAULT NULL,
  `milestone_order` int(11) DEFAULT NULL,
  `task_order` int(11) DEFAULT NULL,
  `progress` int(11) DEFAULT '0',
  `created_at` varchar(50) DEFAULT NULL,
  `start_date` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `start_date`) VALUES ('2', '13', 'Google Analytics', '9', 'open', '1', NULL, '2016-12-09', '', '800', '2', '0', '34', '0', NULL, NULL, '4', NULL, '2', '2', '0', '2016-12-08 07:35:08', '2016-12-08');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `start_date`) VALUES ('3', '13', 'Google Translator', '9', 'open', '1', NULL, '2016-12-16', '', '150', '2', '0', '34', '0', NULL, NULL, '4', NULL, '1', '1', '0', '2016-12-08 07:35:14', '2016-12-08');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `start_date`) VALUES ('4', '13', 'Gmail', '9', 'open', '1', NULL, '2016-12-23', '', '350', '2', '0', '31', '0', NULL, NULL, '5', NULL, NULL, '3', '0', '2016-12-08 07:35:26', '2016-12-08');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `start_date`) VALUES ('5', '13', 'Homepage', '9', 'open', '1', NULL, '2016-12-16', '<p>One porject for homepage Version 1.1<br></p>', '500', '3', '0', '31', '0', NULL, NULL, '5', NULL, '3', '4', '0', '2016-12-08 07:40:15', '2016-12-08');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `start_date`) VALUES ('6', '16', 'News Section', '9', 'open', '1', NULL, '2016-12-16', '', '0', '2', '0', '36', '0', NULL, NULL, '0', NULL, NULL, '0', '0', '2016-12-08 08:36:31', '2016-12-12');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `start_date`) VALUES ('7', '16', 'Telefilm Section', '9', 'done', '1', NULL, '2017-12-07', '', '9', '2', '0', '37', '0', NULL, NULL, '1', NULL, '1', '0', '0', '2016-12-08 08:36:42', '2016-12-08');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`, `client_id`, `created_by_client`, `tracking`, `time_spent`, `milestone_id`, `invoice_id`, `milestone_order`, `task_order`, `progress`, `created_at`, `start_date`) VALUES ('8', '16', 'Digital Media Section', '9', 'open', '1', NULL, '2017-07-07', '', '4', '3', '0', '35', '0', NULL, NULL, '2', NULL, NULL, '0', '0', '2016-12-08 08:36:57', '2016-12-08');


#
# TABLE STRUCTURE FOR: project_has_timesheets
#

DROP TABLE IF EXISTS project_has_timesheets;

CREATE TABLE `project_has_timesheets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `time` varchar(250) DEFAULT '0',
  `task_id` int(11) DEFAULT '0',
  `client_id` int(11) DEFAULT '0',
  `start` varchar(250) DEFAULT '0',
  `end` varchar(250) DEFAULT '0',
  `invoice_id` int(11) DEFAULT '0',
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_workers
#

DROP TABLE IF EXISTS project_has_workers;

CREATE TABLE `project_has_workers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('41', '11', '9');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('42', '12', '9');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('43', '13', '9');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('44', '14', '9');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('45', '15', '9');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('48', '16', '9');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('49', '17', '12');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('50', '17', '9');


#
# TABLE STRUCTURE FOR: projects
#

DROP TABLE IF EXISTS projects;

CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `name` varchar(65) DEFAULT NULL,
  `description` text,
  `start` varchar(20) DEFAULT NULL,
  `end` varchar(20) DEFAULT NULL,
  `progress` decimal(3,0) DEFAULT NULL,
  `phases` varchar(150) DEFAULT NULL,
  `tracking` int(11) DEFAULT NULL,
  `time_spent` int(11) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `sticky` enum('1','0') DEFAULT '0',
  `category` varchar(150) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `note` longtext,
  `progress_calc` tinyint(4) DEFAULT '0',
  `hide_tasks` int(1) DEFAULT '0',
  `enable_client_tasks` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_projects_clients1` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('11', '51001', 'KGN', '1', '2016-12-01', '2016-12-31', '0', 'Planning, Developing, Testing', NULL, NULL, '1481097423', '0', 'Web Development', '25', NULL, '1', '1', '1');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('12', '51002', 'Ann Gerlitz', '', '2016-08-01', '2018-12-31', '0', 'Planning, Developing, Testing', NULL, NULL, '1481115671', '0', 'Multi domain', '27', NULL, '1', '0', '1');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('13', '51003', 'Antago Mario', '', '2016-09-01', '2017-01-31', '0', 'Planning, Developing, Testing', '1481180717', '0', '1481115717', '0', 'Multi domain', '28', NULL, '1', '1', '1');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('14', '51004', 'Mark Zuckerbug', '', '2008-12-01', '2021-12-31', '0', 'Planning, Developing, Testing', NULL, NULL, '1481115773', '0', 'Social Media', '29', NULL, '1', '0', '1');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('15', '51005', 'ICICI', '', '2016-12-05', '2017-12-04', '0', 'Planning, Developing, Testing', NULL, NULL, '1481176249', '0', 'Banking', '30', NULL, '1', '1', '0');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('16', '51006', 'Zee', '', '2016-12-12', '2016-12-16', '33', 'Planning, Developing, Testing', NULL, '0', '1481182545', '0', 'TV', '31', NULL, '1', '0', '1');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`, `hide_tasks`, `enable_client_tasks`) VALUES ('17', '51008', 'TESTING PRO', '', '2016-12-09', '2016-12-16', '0', 'Planning, Developing, Testing', NULL, NULL, '1481261656', '0', 'Banking', '0', NULL, '1', '1', '1');


#
# TABLE STRUCTURE FOR: pw_reset
#

DROP TABLE IF EXISTS pw_reset;

CREATE TABLE `pw_reset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT '0',
  `timestamp` varchar(250) DEFAULT '0',
  `token` varchar(250) DEFAULT '0',
  `user` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: queues
#

DROP TABLE IF EXISTS queues;

CREATE TABLE `queues` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Service', 'First service queue', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('2', 'Second Level', 'Second Level Queue', '0');


#
# TABLE STRUCTURE FOR: quotations
#

DROP TABLE IF EXISTS quotations;

CREATE TABLE `quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) DEFAULT NULL,
  `q2` varchar(50) DEFAULT NULL,
  `q3` varchar(50) DEFAULT NULL,
  `q4` varchar(150) DEFAULT NULL,
  `q5` text,
  `q6` varchar(50) DEFAULT NULL,
  `company` varchar(150) DEFAULT '-',
  `fullname` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(150) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `zip` varchar(150) DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `comment` text,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(150) DEFAULT '0',
  `user_id` int(50) DEFAULT '0',
  `replied` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO quotations (`id`, `q1`, `q2`, `q3`, `q4`, `q5`, `q6`, `company`, `fullname`, `email`, `phone`, `address`, `city`, `zip`, `country`, `comment`, `date`, `status`, `user_id`, `replied`) VALUES ('14', '2', '2', '1', '', 'yes please revert me by email  or call me on my number.', '2', 'xxxx', 'xxx', 'emailtesterone@gmail.com', '999999999', 'iscon elegance', 'Ahmedabad', '380015', 'India', '', '2016-12-07 11:19', 'New', '0', '0');


#
# TABLE STRUCTURE FOR: subscription_has_items
#

DROP TABLE IF EXISTS subscription_has_items;

CREATE TABLE `subscription_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscription_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` text,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: subscriptions
#

DROP TABLE IF EXISTS subscriptions;

CREATE TABLE `subscriptions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) DEFAULT NULL,
  `company_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `frequency` varchar(20) DEFAULT NULL,
  `next_payment` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscribed` varchar(50) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  `second_tax` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO subscriptions (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `end_date`, `frequency`, `next_payment`, `terms`, `discount`, `subscribed`, `tax`, `second_tax`) VALUES ('11', '61001', '25', 'Active', '$2000', '2016-12-05', '2016-12-10', '+7 day', '2016-12-05', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '', '0', '0', '');


#
# TABLE STRUCTURE FOR: templates
#

DROP TABLE IF EXISTS templates;

CREATE TABLE `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `text` text,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ticket_has_articles
#

DROP TABLE IF EXISTS ticket_has_articles;

CREATE TABLE `ticket_has_articles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `from` varchar(250) NOT NULL DEFAULT '0',
  `reply_to` varchar(250) DEFAULT '0',
  `to` varchar(250) DEFAULT '0',
  `cc` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` text,
  `datetime` varchar(250) DEFAULT NULL,
  `internal` int(10) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;

INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('120', '52', 'John Doe - local@localhost', 'local@localhost', '0', '0', 'checking this issue', '', '1481102575', '0');
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('121', '52', 'John Doe - local@localhost', 'local@localhost', 'emailtesterone@gmail.com', '0', 'Close', '', '1481102620', '0');


#
# TABLE STRUCTURE FOR: ticket_has_attachments
#

DROP TABLE IF EXISTS ticket_has_attachments;

CREATE TABLE `ticket_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from` varchar(250) DEFAULT '0',
  `reference` varchar(250) DEFAULT '0',
  `type_id` smallint(6) DEFAULT '1',
  `lock` smallint(6) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `text` text,
  `status` varchar(50) DEFAULT '0',
  `client_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `escalation_time` int(11) DEFAULT '0',
  `priority` varchar(50) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  `queue_id` int(11) DEFAULT '0',
  `updated` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('52', 'John Doe - emailtesterone@gmail.com', '10000', '1', '0', 'tHERE IS AN ISSUE AT IN THIS PAGE', '', 'closed', '27', '25', '10', '0', '0', '1481101307', '2', '1');
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('53', 'John Doe - emailtesterone@gmail.com', '10001', '1', '0', 'Add Page has issue no.1', '<p>Add Page has issue no.1<br></p>', 'open', '27', '25', '10', '0', '0', '1481102671', '2', '1');
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('54', 'John Doe - emailtesterone@gmail.com', '10002', '1', '0', 'Add Page has issue no.2', '<p>Add Page has issue no.2<br></p>', 'onhold', '27', '25', '10', '0', '0', '1481102702', '1', '1');
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('55', 'John Doe - emailtesterone@gmail.com', '10003', '1', '0', 'Hi can you please lookinto this issue', '<p>Hi can you please lookinto this issue<br></p>', 'open', '27', '25', '10', '0', '0', '1481102862', '1', '1');


#
# TABLE STRUCTURE FOR: types
#

DROP TABLE IF EXISTS types;

CREATE TABLE `types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Service Request', 'Service Requests', '0');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `firstname` varchar(120) DEFAULT NULL,
  `lastname` varchar(120) DEFAULT NULL,
  `hashed_password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT NULL,
  `admin` enum('0','1') DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userpic` varchar(250) DEFAULT 'no-pic.png',
  `title` varchar(150) DEFAULT NULL,
  `access` varchar(150) NOT NULL DEFAULT '1,2',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `queue` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('9', 'Admin', 'John', 'Doe', '785ea3511702420413df674029fe58d69692b3a0a571c0ba30177c7808db69ea22a8596b1cc5777403d4374dafaa708445a9926d6ead9a262e37cb0d78db1fe5', 'emailtesterfour@gmail.com', 'active', '1', '2016-02-01 00:00:00', '27e0729f9ce899cda553e02f98883df2.jpg', 'Administrator', '1,2,3,4,5,18,19,8,6,7,16,20,33,9,10,11', '1481292718', '1481292676', '1');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('10', 'Admin1', 'Robot', 'Doe', '4988a7c1551ec42c8e46203d8edc6e296378f7fee0df597a09dff83dba0ef275a8416803889d2ede963367336529eac14da8c7c0ad2a57d7c9edc55f1c5dc904', 'emailtesterone@gmail.com', 'active', '0', '2016-12-07 13:24:49', '66539f4ec4239a04fb94abea997edc03.jpg', 'Mr.', '1,2,3,4,5,18,19,8,6,7,16,20,33,9,10,11', '0', '1481112973', '2');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('11', 'Admin2', 'Ann ', 'Gerlitz', '3e73d007c3785de5c61bd6f49f4e68972ae1229da02aef2228d07de14970aa4e94158561660015c2e942beb8a5064f2dc58ce1bf9a207ae1689f8304af6c1e77', 'emailtesterone@gmail.com', 'active', '0', '2016-12-07 17:54:01', '5e6ed38edbcdb018e87c6753ad30caff.png', 'Ms.', '1,2,3,4,8,10,11', '1481197041', '1481196992', '1');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('12', 'Admin3', 'Antago', 'Mario', 'e619edeb235ef0639e532db741786b52a33171f30410fc91a5f3627b3f9011ced5e442ed1269a2eab62795dc9829015a11eda3a2062161197519f79f62f2155a', 'emailtestertwo@gmail.com', 'active', '0', '2016-12-07 17:55:14', 'ab08f770cb3fe06e85fbf57bdefa83de.png', 'Mr.', '1,2,3,18,19,7,16,10,11', '0', '1481198473', '1');


